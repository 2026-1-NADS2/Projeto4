-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_bruno
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anuncios`
--

DROP TABLE IF EXISTS `anuncios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anuncios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `produto` varchar(250) NOT NULL,
  `preco` double(5,2) NOT NULL,
  `quantidade` int(2) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anuncios`
--

LOCK TABLES `anuncios` WRITE;
/*!40000 ALTER TABLE `anuncios` DISABLE KEYS */;
INSERT INTO `anuncios` VALUES (1,'Carlos Mendes','carlos.mendes12@email.com','Coca-Cola 2L',9.50,2,'Refrigerante Coca-Cola garrafa 2 litros','Bebidas','2026-03-24 01:11:02'),(2,'Ana Souza','ana.souza@email.com','Suco de Laranja Natural',7.00,1,'Suco natural integral sem açúcar','Bebidas','2026-03-24 01:11:02'),(4,'Fernanda Alves','fernanda.alves@email.com','Cerveja Heineken Long Neck',6.99,1,'Cerveja premium long neck 330ml','Bebidas','2026-03-24 01:11:02'),(5,'Ricardo Martins','ricardo.martins@email.com','Queijo Mussarela 500g',18.00,500,'Queijo mussarela fatiado','Frios','2026-03-24 01:11:02'),(6,'Juliana Rocha','juliana.rocha@email.com','Presunto Cozido 500g',15.00,500,'Presunto cozido fatiado','Frios','2026-03-24 01:11:02'),(7,'Marcos Pereira','marcos.pereira@email.com','Peito de Peru 300g',16.50,300,'Peito de peru defumado','Frios','2026-03-24 01:11:02'),(8,'Patrícia Gomes','patricia.gomes@email.com','Leite Integral 1L',5.20,1,'Leite integral longa vida','Laticínios','2026-03-24 01:11:02'),(9,'Lucas Ribeiro','lucas.ribeiro@email.com','Iogurte Natural 170g',3.50,170,'Iogurte natural sem açúcar','Laticínios','2026-03-24 01:11:02'),(10,'Camila Fernandes','camila.fernandes@email.com','Manteiga 200g',9.00,200,'Manteiga com sal','Laticínios','2026-03-24 01:11:02'),(11,'Eduardo Carvalho','eduardo.carvalho@email.com','Pão Francês',0.80,1,'Pão francês fresco unidade','Padaria','2026-03-24 01:11:02'),(12,'Aline Costa','aline.costa@email.com','Pão de Forma',8.50,500,'Pão de forma tradicional','Padaria','2026-03-24 01:11:02'),(13,'Gustavo Santos','gustavo.santos@email.com','Bolo de Chocolate',25.00,700,'Bolo caseiro de chocolate','Padaria','2026-03-24 01:11:02'),(14,'Renata Oliveira','renata.oliveira@email.com','Arroz 5kg',28.00,5000,'Arroz branco tipo 1','Mercearia','2026-03-24 01:11:02'),(15,'Felipe Nogueira','felipe.nogueira@email.com','Feijão Carioca 1kg',8.50,1000,'Feijão tipo carioca','Mercearia','2026-03-24 01:11:02'),(16,'Larissa Teixeira','larissa.teixeira@email.com','Macarrão Espaguete 500g',4.20,500,'Macarrão tipo espaguete','Mercearia','2026-03-24 01:11:02'),(17,'André Barros','andre.barros@email.com','Carne Bovina Alcatra 1kg',45.00,1000,'Corte de alcatra fresca','Carnes','2026-03-24 01:11:02'),(18,'Vanessa Duarte','vanessa.duarte@email.com','Frango Inteiro 1kg',12.00,1000,'Frango inteiro resfriado','Carnes','2026-03-24 01:11:02'),(19,'Thiago Freitas','thiago.freitas@email.com','Linguiça Toscana 1kg',18.00,1000,'Linguiça fresca temperada','Carnes','2026-03-24 01:11:02'),(20,'Isabela Moraes','isabela.moraes@email.com','Maçã Gala 1kg',6.50,1000,'Maçã gala fresca','Hortifruti','2026-03-24 01:11:02'),(21,'Rafael Batista','rafael.batista@email.com','Banana Prata 1kg',5.00,1000,'Banana prata madura','Hortifruti','2026-03-24 01:11:02'),(22,'Daniela Pires','daniela.pires@email.com','Tomate 1kg',7.00,1000,'Tomate fresco','Hortifruti','2026-03-24 01:11:02'),(23,'João Vitor','joao.vitor@email.com','Chocolate ao Leite 100g',4.50,100,'Chocolate ao leite barra','Doces','2026-03-24 01:11:02'),(24,'Marina Lopes','marina.lopes@email.com','Bala de Gelatina 200g',3.80,200,'Bala de gelatina sortida','Doces','2026-03-24 01:11:02'),(25,'Pedro Henrique','pedro.henrique@email.com','Sorvete 1L',19.00,1000,'Sorvete cremoso diversos sabores','Doces','2026-03-24 01:11:02'),(26,'Fabricio Aguiar','fabricio.aguiar0@email.com','Dr. Pepper 350ml',13.00,26,'Refrigerante Dr. pepper garrafa 350 ml','Bebidas','2026-03-26 22:48:00'),(28,'Bruno Faccio','bruno.tntfaccio@email.com','Dolly 2L',10.00,30,'Refrigerante Dolly sabor Laranja garrafa 2 Litros','Bebidas','2026-03-26 22:57:16'),(30,'Bruno Faccio','bruno.tntfaccio@emaippl.com','Dolly 2L',10.00,30,'Refrigerante Dolly sabor Laranja garrafa 2 Litros','Bebidas','2026-03-26 23:05:35'),(32,'Bruno Faccio','bruno.tntfaccio@emaipp123l.com','Dolly 2L',10.00,30,'Refrigerante Dolly sabor Laranja garrafa 2 Litros','Bebidas','2026-03-26 23:06:34'),(33,'Bruno Faccio','bruno.tntfaccio@emaipp1hh23l.com','Dolly 2L',10.00,30,'Refrigerante Dolly sabor Laranja garrafa 2 Litros','Bebidas','2026-03-26 23:06:40'),(35,'Bruno Faccio','bruno.tntfaccio@emaipphh1hh23l.com','Dolly 2L',10.00,30,'Refrigerante Dolly sabor Laranja garrafa 2 Litros','Bebidas','2026-03-26 23:06:46');
/*!40000 ALTER TABLE `anuncios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-26 21:53:44
