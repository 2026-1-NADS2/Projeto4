import { Router } from 'express'
import { pool } from './db.js'

const r = Router()


// GET Visualizar todos os anuncios.

// http://localhost:3000/api/anuncios
r.get('/anuncios', async (_, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT id, name, email, produto, preco, quantidade, descricao, categoria, created_at
             FROM anuncios
             ORDER BY id DESC`
        )
        res.json(rows)
    } catch (error) {
    console.error('Erro ao listar anúncios:', error)
    res.status(500).json({ error: 'Erro ao listar anúncios', detalhe: error.message })
}
    }
)

// GET Visualizar anuncio por anuncio (1 à 26)

// http://localhost:3000/api/anuncios/1

r.get('/anuncios/:id', async (req, res) => {
    const { id } = req.params

    try {
        const [rows] = await pool.query(
            `SELECT id, name, email, produto, preco, quantidade, descricao, categoria, created_at
             FROM anuncios
             WHERE id = ?`,
            [id]
        )

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Anúncio não encontrado' })
        }

        res.json(rows[0])
    } catch {
        res.status(500).json({ error: 'Erro ao buscar anúncio' })
    }
})

// POST Inserir um novo anuncio (Possui auto increment no ID e Data Criada)

// http://localhost:3000/api/anuncios

r.post('/anuncios', async (req, res) => {
    const { name, email, produto, preco, quantidade, descricao, categoria } = req.body

    if (!name || !email || !produto || preco == null || quantidade == null || !descricao || !categoria) {
        return res.status(400).json({
            error: 'name, email, produto, preco, quantidade, descricao e categoria são obrigatórios'
        })
    }

    try {
        const [result] = await pool.query(
            `INSERT INTO anuncios (name, email, produto, preco, quantidade, descricao, categoria)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [name, email, produto, preco, quantidade, descricao, categoria]
        )

        res.status(201).json({ id: result.insertId })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Email já cadastrado' })
        }

        res.status(500).json({ error: 'Erro ao criar anúncio' })
    }
})

// DELETE Deletar anuncios (selecionar por id)
// http://localhost:3000/api/anuncios/1
r.delete('/anuncios/:id', async (req, res) => {
    const { id } = req.params

    try {
        const [result] = await pool.query(
            'DELETE FROM anuncios WHERE id = ?',
            [id]
        )

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Anúncio não encontrado' })
        }

        res.json({ message: 'Anúncio excluído com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao excluir anúncio' })
    }
})

// PUT Anuncios UPDATE - Atualiza um anuncio.
// http://localhost:3000/api/anuncios/1
r.put('/anuncios/:id', async (req, res) => {
    const { id } = req.params
    const { name, email, produto, preco, quantidade, descricao, categoria } = req.body

    if (!name || !email || !produto || preco == null || quantidade == null || !descricao || !categoria) {
        return res.status(400).json({
            error: 'name, email, produto, preco, quantidade, descricao e categoria são obrigatórios'
        })
    }

    try {
        const [result] = await pool.query(
            `UPDATE anuncios
             SET name = ?, email = ?, produto = ?, preco = ?, quantidade = ?, descricao = ?, categoria = ?
             WHERE id = ?`,
            [name, email, produto, preco, quantidade, descricao, categoria, id]
        )

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Anúncio não encontrado' })
        }

        const [rows] = await pool.query(
            `SELECT id, name, email, produto, preco, quantidade, descricao, categoria, created_at
             FROM anuncios
             WHERE id = ?`,
            [id]
        )

        res.json(rows[0])
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Email já cadastrado' })
        }

        res.status(500).json({ error: 'Erro ao atualizar anúncio' })
    }
})

export default r