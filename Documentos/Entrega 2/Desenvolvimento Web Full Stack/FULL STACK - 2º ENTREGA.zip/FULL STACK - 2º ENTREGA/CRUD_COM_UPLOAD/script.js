const usersList = document.getElementById('usersList')

const userForm = document.getElementById('userForm')

const loading = document.getElementById('loading')

const nameInput = document.getElementById('name')

const emailInput = document.getElementById('email')

const vulgoInput = document.getElementById('vulgo')

const imageInput = document.getElementById('image')

let editingId = null

const API_URL = 'http://localhost:3000/api/users'

async function getUsers(){

    loading.innerText = 'Carregando usuários...'

    try{

        const response = await fetch(API_URL)

        const users = await response.json()

        console.log(users)

        usersList.innerHTML = ''

        if(users.length === 0){

            usersList.innerHTML = `
                <p>Nenhum usuário cadastrado</p>
            `
        }

        users.forEach(user => {

            const imageUrl = user.img
                ? `http://localhost:3000/${user.img}`
                : null

            usersList.innerHTML += `

                <div class="user-card">

                    <h2>${user.name}</h2>

                    <p>${user.email}</p>

                    <p>
                        <strong>Vulgo:</strong>
                        ${user.vulgo || 'Sem vulgo'}
                    </p>

                    <p class="created-date">

                        Criado em:

                        ${new Date(user.created_at)
                            .toLocaleDateString('pt-BR')}

                    </p>

                    ${
                        imageUrl
                        ?
                        `
                            <img
                                src="${imageUrl}"
                                class="preview-image"
                                alt="Imagem do usuário"
                            >
                        `
                        :
                        `
                            <p>Sem imagem</p>
                        `
                    }

                    <div class="buttons">

                        <button
                            class="edit-btn"
                            onclick="editUser(${user.id})"
                        >
                            Editar
                        </button>

                        <button
                            class="delete-btn"
                            onclick="deleteUser(${user.id})"
                        >
                            Excluir
                        </button>

                    </div>

                </div>

            `
        })

    } catch(error){

        console.log(error)

        alert('Erro ao carregar usuários')
    }

    loading.innerText = ''
}

getUsers()

userForm.addEventListener('submit', async (e) => {

    e.preventDefault()

    const formData = new FormData()

    formData.append('name', nameInput.value)

    formData.append('email', emailInput.value)

    formData.append('vulgo', vulgoInput.value)

    if(imageInput.files[0]){

        formData.append('image', imageInput.files[0])
    }

    try{

        let response

        if(editingId){

            response = await fetch(`${API_URL}/${editingId}`, {

                method:'PUT',

                body: formData
            })

            editingId = null

        } else {

            response = await fetch(API_URL, {

                method:'POST',

                body: formData
            })
        }

        if(!response.ok){

            const errorData = await response.json()

            throw new Error(errorData.error)
        }

        userForm.reset()

        imageInput.value = ''

        vulgoInput.value = ''

        getUsers()

    } catch(error){

        console.log(error)

        alert(error.message)
    }
})

async function editUser(id){

    try{

        const response = await fetch(`${API_URL}/${id}`)

        const user = await response.json()

        nameInput.value = user.name

        emailInput.value = user.email

        vulgoInput.value = user.vulgo || ''

        editingId = id

        window.scrollTo({

            top: 0,

            behavior: 'smooth'
        })

    } catch(error){

        console.log(error)

        alert('Erro ao carregar usuário')
    }
}

async function deleteUser(id){

    const confirmDelete = confirm(
        'Deseja excluir este usuário?'
    )

    if(!confirmDelete){

        return
    }

    try{

        const response = await fetch(`${API_URL}/${id}`, {

            method:'DELETE'
        })

        if(!response.ok){

            const errorData = await response.json()

            throw new Error(errorData.error)
        }

        getUsers()

    } catch(error){

        console.log(error)

        alert(error.message)
    }
}