import express from 'express'
import cors from 'cors'
import routes from './routes.js'
import path from 'path'

const app = express()

app.use(cors())

app.use(express.json())

app.use(
    '/uploads',
    express.static(path.join(process.cwd(), 'uploads'))
)

app.use('/api', routes)

const PORT = 3000

app.listen(PORT, () => {

    console.log(`Servidor rodando na porta ${PORT}`)
})