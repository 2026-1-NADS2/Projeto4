import { pool } from '../db.js'
import fs from 'fs'

// Criar Usuário
// http://localhost:3000/api/users

export async function createUser(req, res) {

    const { name, email, vulgo } = req.body

    if (!name || !email) {

        if (req.file) {
            fs.unlink(req.file.path, () => {})
        }

        return res.status(400).json({
            error: 'Nome e Email são Obrigatórios'
        })
    }

    const imgPath = req.file
        ? `uploads/${req.file.filename}`
        : null

    try {

        const [result] = await pool.query(

            'INSERT INTO users (name, email, vulgo, img) VALUES (?, ?, ?, ?)',

            [name, email, vulgo, imgPath]
        )

        res.status(201).json({

            id: result.insertId,

            name,

            email,

            img: imgPath
        })

    } catch (err) {

        if (req.file) {
            fs.unlink(req.file.path, () => {})
        }

        if (err.code === 'ER_DUP_ENTRY') {

            return res.status(409).json({
                error: 'Email já Cadastrado'
            })
        }

        res.status(500).json({
            error: 'Erro ao criar usuário'
        })
    }
}

// Listar Todos os Usuários
// http://localhost:3000/api/users

export async function getUsers(_, res) {

    try {

        const [rows] = await pool.query(

            'SELECT id, name, email, vulgo, img, created_at FROM users ORDER BY id DESC'
        )

        res.json(rows)

    } catch {

        res.status(500).json({
            error: 'Erro ao listar usuários'
        })
    }
}

// Buscar usuário por ID
// http://localhost:3000/api/users/1

export async function getUserById(req, res) {

    const { id } = req.params

    try {

        const [rows] = await pool.query(

            'SELECT id, name, email, vulgo, img, created_at FROM users WHERE id=?',

            [id]
        )

        if (rows.length === 0) {

            return res.status(404).json({
                error: 'Usuário não encontrado'
            })
        }

        res.json(rows[0])

    } catch {

        res.status(500).json({
            error: 'Erro ao buscar usuário'
        })
    }
}

// Deletar Usuário
// http://localhost:3000/api/users/1

export async function deleteUser(req, res) {

    const { id } = req.params

    try {

        const [rows] = await pool.query(

            'SELECT * FROM users WHERE id=?',

            [id]
        )

        if (!rows.length) {

            return res.status(404).json({
                error: 'Usuário não encontrado'
            })
        }

        const imgPath = rows[0].img

        await pool.query(

            'DELETE FROM users WHERE id=?',

            [id]
        )

        if (imgPath) {

            fs.unlink(imgPath, err => {

                if (err) {

                    console.warn(
                        'Erro ao remover imagem:',
                        err
                    )
                }
            })
        }

        res.json({
            message: 'Usuário deletado com sucesso'
        })

    } catch {

        res.status(500).json({
            error: 'Erro ao excluir usuário'
        })
    }
}

// Atualizar Usuário
// http://localhost:3000/api/users/1

export async function updatedUser(req, res) {

    const { id } = req.params

    const { name, email, vulgo } = req.body

    if (!name || !email) {

        return res.status(400).json({
            error: 'Nome e email obrigatórios'
        })
    }

    try {

        const [rows] = await pool.query(

            'SELECT * FROM users WHERE id=?',

            [id]
        )

        if (rows.length === 0) {

            return res.status(404).json({
                error: 'Usuário não encontrado'
            })
        }

        const oldImg = rows[0].img

        const newImg = req.file
            ? `uploads/${req.file.filename}`
            : oldImg

        const [result] = await pool.query(

            'UPDATE users SET name=?, email=?, vulgo=?, img=? WHERE id=?',

            [name, email, vulgo, newImg, id]
        )

        if (result.affectedRows === 0) {

            return res.status(404).json({
                error: 'Usuário não encontrado'
            })
        }

        if (req.file && oldImg) {

            fs.unlink(oldImg, err => {

                if (err) {

                    console.warn(
                        'Erro ao remover imagem:',
                        err
                    )
                }
            })
        }

        const [updated] = await pool.query(

            'SELECT id, name, email, img, created_at FROM users WHERE id=?',

            [id]
        )

        res.json(updated[0])

    } catch (err) {

        if (err.code === 'ER_DUP_ENTRY') {

            return res.status(409).json({
                error: 'Email já cadastrado'
            })
        }

        res.status(500).json({
            error: 'Erro ao atualizar usuário'
        })
    }
}

// Atualizar nome e/ou senha

export async function updateMe(req, res) {

    res.json({
        message: 'Função updateMe ainda não implementada'
    })
}

// Perfil

export async function profile(req, res) {

    try {

        const [rows] = await pool.query(

            'SELECT id, name, email, img, created_at FROM users WHERE id=?',

            [req.user.id]
        )

        if (!rows.length) {

            return res.status(404).json({
                error: 'Usuário não encontrado'
            })
        }

        res.json(rows[0])

    } catch {

        res.status(500).json({
            error: 'Erro ao buscar perfil'
        })
    }
}