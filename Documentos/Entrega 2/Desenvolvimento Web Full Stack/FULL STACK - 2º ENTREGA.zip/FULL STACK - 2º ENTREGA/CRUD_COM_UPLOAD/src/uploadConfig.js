import multer from 'multer'
import path from 'path'
import fs from 'fs'

const uploadDir = path.join(process.cwd(), 'uploads')

if (!fs.existsSync(uploadDir)) {

    fs.mkdirSync(uploadDir, {
        recursive: true
    })
}

const storage = multer.diskStorage({

    destination: (req, file, cb) => {

        cb(null, uploadDir)
    },

    filename: (req, file, cb) => {

        const ext = path.extname(file.originalname)

        const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`

        cb(null, uniqueName)
    }
})

const upload = multer({

    storage,

    limits: {
        fileSize: 10 * 1024 * 1024
    }
})

export default upload