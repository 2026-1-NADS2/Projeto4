import { Router } from 'express'
import upload from './uploadConfig.js'

import {
    register,
    login,
    logout,
    forgotPassword
} from './controllers/authController.js'

import {
    getUsers,
    getUserById,
    createUser,
    updatedUser,
    deleteUser,
    profile,
    updateMe
} from './controllers/useController.js'

const r = Router()

// ========================
// ROTAS PÚBLICAS
// ========================

r.post('/auth/register', register)
r.post('/auth/login', login)
r.post('/auth/forgot-password', forgotPassword)

// ========================
// ROTAS DE PERFIL
// ========================

// Comentadas temporariamente para facilitar a entrega

// r.post('/auth/logout', verifyTokenMiddleware, logout)

// r.get('/users/profile', verifyTokenMiddleware, profile)

// r.put('/users/me', verifyTokenMiddleware, updateMe)

// ========================
// CRUD DE USUÁRIOS
// ========================

// LISTAR
r.get('/users', getUsers)

// BUSCAR POR ID
r.get('/users/:id', getUserById)

// CRIAR
r.post(
    '/users',
    upload.single('image'),
    createUser
)

// EDITAR
r.put(
    '/users/:id',
    upload.single('image'),
    updatedUser
)

// DELETAR
r.delete('/users/:id', deleteUser)

export default r