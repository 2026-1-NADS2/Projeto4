create database if not exists aula_backend;
use aula_backend;

create table if not exists users(
	id int primary key auto_increment,
    name varchar(250) not null,
    email varchar(250) not null unique,
    img varchar(255) null,
    created_at timestamp default current_timestamp
);

show tables;
describe users;
select*from users;
alter table users add column img varchar(255) null;
insert into users (name, email) values ('Fecap', 'fecap@teste.com');