# Mangút - Marketplace B2B

## Sobre o Projeto
O Mangút é uma plataforma Marketplace B2B desenvolvida para conectar empresas e usuários em um ambiente de compra, venda e publicação de anúncios. O sistema possui autenticação de usuários, publicação de anúncios com upload de imagens e páginas separadas para cadastro, login, compras e gerenciamento de anúncios.

O projeto foi desenvolvido utilizando Node.js no back-end, MySQL como banco de dados e HTML, CSS e JavaScript puro no front-end.

---

# Tecnologias Utilizadas

## Back-end
- Node.js
- Express
- MySQL2
- Multer
- Bcrypt
- Cors
- Dotenv
- Nodemon

## Front-end
- HTML5
- CSS3
- JavaScript

## Banco de Dados
- MySQL

---

# Estrutura do Projeto

```bash
CRUD_COM_UPLOAD/
│
├── imagens/
├── src/
├── tela_cadastro/
├── tela_compras/
├── tela_login/
├── tela_principal/
├── tela_publicar_anuncio/
├── uploads/
├── banco.sql
├── package.json
└── .env
```

---

# Funcionalidades

- Cadastro de usuários
- Login de usuários
- Publicação de anúncios
- Upload de imagens
- Visualização de anúncios
- Página principal com carrossel
- Integração com banco de dados MySQL
- Organização de rotas utilizando Express

---

# Configuração do Projeto

## Instalar Dependências

```bash
npm install
```

## Executar o Projeto

### Desenvolvimento

```bash
npm run dev
```

### Produção

```bash
npm start
```

---

# Objetivo do Projeto

O objetivo do Mangút é facilitar a conexão entre empresas e compradores em um ambiente digital simples, moderno e funcional.

---

# Melhorias Futuras

- Sistema JWT
- Chat entre usuários
- Sistema de favoritos
- Painel administrativo
- Integração com pagamentos

---

# Autor

Projeto desenvolvido para fins acadêmicos e aprendizado em desenvolvimento web full stack utilizando Node.js, MySQL e JavaScript.
